from django.contrib import admin
from .models import *

admin.site.register(DiamondReport)
admin.site.register(HomeBanner)
admin.site.register(AboutSection)
admin.site.register(ContactInfo)
admin.site.register(ContactMessage)